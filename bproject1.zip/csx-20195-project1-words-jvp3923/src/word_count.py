"""
Count the total number of occurrences of a word across all years in a unigram file.
$ python word_count.py [-h] word filename
Author: Jude Paulemon
"""
import argparse
from typing  import Dict
from dataclasses import dataclass
import sys
import file_handler as fr



def main()-> None:
    """
    parse the arguments passed by the user.
    read a unigram file, then displayed the number of times a given word has occured
    :return: None
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('word')
    parser.add_argument('file_name')
    args = parser.parse_args()

    words = fr.read_file(args.file_name);

    if args.word in words:
        print(args.word +': ' + str(words[args.word].total_occurence))
    else:
        print('Error: ' +args.word+' does not appear!')
        exit()
    #print(words);

if __name__ == '__main__':
    main()