"""
Compute thefrequency of each letter, a-z, across the total occurrences of all words over all years.
$ python letter_freq.py [-h] [-o] [-p] filename
Author: Jude Paulemon
"""

import argparse
from typing import Dict, List
from dataclasses import dataclass
import file_handler as fr
import numpy as np
import matplotlib.pyplot as plt
import time



def main():
    """
    The main function.
    :return: None
    """
    
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-o', '--output', help='display letter frequencies to standard output',action='store_true')
    parser.add_argument(
        '-p', '--plot', help=' plot letter frequencies using matplotlib',action='store_true')
    
    parser.add_argument('file_name')
    args = parser.parse_args()

    words = fr.read_file(args.file_name)

    freq = letter_freq(words)

    output(freq,args)

def output(freq,args)->None:
    """
    plot and print the letter frequencies
    :param freq: contains a list of frequencies
    :param args: list of arguments
    :return: None
    """
    if args.output:
        for i in range(97, 123):
            char = chr(i)
            print(char+': '+str(freq[i-97]))

    if args.plot:
        plt.title('Letter frequencies: '+args.file_name)
        plt.xlabel('Letter')
        plt.ylabel('Frequency')
        for i in range(97, 123):
            char = chr(i)
            plt.bar(char, freq[i-97], width=1, bottom=None,
                    align='center', data=None, color='b', edgecolor='k')
        plt.tick_params(bottom = True, top = True, left = True, right = True)
        plt.margins(0)
        plt.show()

def letter_freq(data: Dict) -> List[int]:
    """
    Calcutate the frequencie of each letter
    :param data: Dict of words
    :return: List of int (frequencies)
    """
    alphapbet = {

    }
    sum_occurence = 0
    for word in data:
        for c in word:
            if c not in alphapbet:
                alphapbet[c] = data[word].total_occurence
            else:
                alphapbet[c] = alphapbet[c] + data[word].total_occurence

            sum_occurence = sum_occurence + data[word].total_occurence

    frequency = list()

    f = np.array([])

    sum_frequency = 0
    for x in range(97, 123):
        char = chr(x)
        if char not in alphapbet:
            f = np.append(f, 0.0)
        else:
            f = np.append(f, alphapbet[char]/sum_occurence)
    return f


if __name__ == '__main__':
    main()
