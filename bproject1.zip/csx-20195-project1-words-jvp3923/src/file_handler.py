"""
helper file that provide a function to read a file into a dictionary
and sort function to sort the keys of a dictionary
Author: Jude Paulemon
"""
from typing  import Dict, List, Tuple
from dataclasses import dataclass
import collections

"""
dataclass that will store a word and metada from an unigram file
"""
@dataclass
class Word:
    """
    Store the location and name.
    :param word: the actual
    :param info: dictionary that contains a list of tuple that store the year and number of occurences
    :praram total_occurence: the total number of occurences across all year
    :pram rank: overall rank base on total_occurence
    """
    word: str
    info: dict
    total_occurence: int
    rank: int

    def get_number_occurence(self):
        return self.total_occurence
    def get_info(self):
        return self.info

def read_file(file_name: str) -> Dict:
    """
    read a file unigram and store its field in dictionary
    :param file_name: the file's name to open
    :return: Dict
    """
    Word_Info = collections.namedtuple('Word_Info', 'year n_occurences')
    prevWord = ''
    words = {

    }
    try:
        with open(file_name) as f:
            for line in f:
                field = line.split(', ')
                if field[0] != prevWord:
                    words[field[0]] = Word(field[0], dict(), int(field[2]),-1)
                    word_info  = {

                    }
                    word_info[field[1]] = Word_Info(int(field[1]), int(field[2]))
                    words[field[0]].info.update(word_info)
                else:
                    word_info  = {

                    }
                    word_info[field[1]] = Word_Info(int(field[1]), int(field[2]))
                    words[field[0]].info.update(word_info)
                    words[field[0]].total_occurence = words[field[0]].total_occurence + int(field[2])
                prevWord = field[0]
    except OSError:
        print('Error: '+ file_name +' does not exist')
        exit()
    return words

def _partition(data: Dict,keys,left,right) -> Tuple[Dict, Dict, Dict]:
    """
    Three way partition the data into smaller, equal and greater lists,
    in relationship to the pivot
    :param data: The data to be sorted (a list)
    :param pivot: The value to partition the data on
    :return: Three list: smaller, equal and greater
    """
    pivot  = data[keys[right]].get_number_occurence()
    p_index = left-1
    for x in range(left,right):
        if data[keys[x]].get_number_occurence() <= pivot:
            p_index +=1
            keys[x],keys[p_index] = keys[p_index],keys[x]

            
    keys[p_index+1],keys[right] = keys[right],keys[p_index+1]
    data[keys[p_index+1]].rank = len(data)-(p_index+1)
    return p_index+1

def quick_sort(data: Dict,keys=None,left=0,right=0) -> List[Word]:
    """
    Performs a quick sort and returns a newly sorted list
    :param data: The data to be sorted (a list)
    :return: A sorted list
    """
    if keys == None:
        keys = list(data.keys())
        left = 0
        right = len(keys)-1
    if left > right:
        return keys
    else:
        #print(keys)
        p = _partition(data,keys,left,right)
        quick_sort(data,keys,left,p-1)
        quick_sort(data,keys,p+1,right)
        return keys