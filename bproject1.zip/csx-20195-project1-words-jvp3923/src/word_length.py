"""
Compute the average word length over a range of years
$ python word_length.py [-h] [-o] [-p] start end filename
Author: Jude Paulemon
"""
import argparse
import file_handler as fr
from typing import List,Dict,Tuple
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import time

def main():
    """
    The main function.
    :return: None
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-o', '--output', help=' display the average word lengths over years', action='store_true')
    parser.add_argument('-p', '--plot', help='plot the average word lengths over years',action='store_true')
    parser.add_argument('start',help='the starting year range')
    parser.add_argument('end',help='the ending year range')
    parser.add_argument('file_name',help=' a comma separated value unigram file')
    args = parser.parse_args()
    if int(args.start) > int(args.end):
        print('Error: start year must be less than or equal to end year!')
        exit()
    words = fr.read_file(args.file_name)

    avg_worg_length(words,words.keys(),args)

def avg_worg_length(data: Dict,keys: List[str],args: Tuple)->Dict:
    """
    calculate the avg lenght of words during a given year
    :param data: Dictionary of words
    :param keys: List of keys of the dictionary
    :param args: arguments passed by the user
    :return: Dict    
    """
    years = {

    }

    for k in keys:
        for x in range(int(args.start),int(args.end)+1):
           if str(x)  in data[k].info:
                if str(x) not in years:
                    years[str(x)] = (len(data[k].word),1)
                else:
                    years[str(x)] = (years[str(x)][0] + len(data[k].word),years[str(x)][1]+1)
    
    word_avg_length_list = np.array([])
    year_range = np.array([])
    for k in range(int(args.start),int(args.end)+1):
        avg = years[str(k)][0]/years[str(k)][1]
        word_avg_length_list = np.append(word_avg_length_list,avg)
        year_range =np.append(year_range,k)
    if args.output:
        for k in range((int(args.end)-int(args.start))+1):
            print(str(int(year_range[k])) + ': ' + str(word_avg_length_list[k]))
    if args.plot:
        plt.plot(year_range,word_avg_length_list)
        plt.title('Average word lengths from '+ args.start +' to ' +  args.end)
        plt.xlabel('Year')
        plt.ylabel('Average word length')
        plt.tick_params(bottom = True, top = True, left = True, right = True)
        plt.margins(0)
        plt.show()
    return years

if __name__ == '__main__':
    main()