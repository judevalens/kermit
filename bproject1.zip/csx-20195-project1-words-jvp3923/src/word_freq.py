"""
compute the popularity of a word in terms of the number of occurrences of all words over all years
$ python word_freq.py [-h] [-o OUTPUT] [-p] word filename
Author: Jude Paulemon
"""
import argparse
import file_handler as fr
from typing import List,Dict,Tuple
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import time


def main():
    """
    The main function.
    :return: None
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-o', '--output', help='display the top OUTPUT (#) ranked words by number of occurrences')
    parser.add_argument('-p', '--plot', help=' plot word frequencies using matplotlib',action='store_true')
    parser.add_argument('word',help='a word to display the overall ranking of')
    parser.add_argument('file_name',help=' a comma separated value unigram file')
    args = parser.parse_args()


    words = fr.read_file(args.file_name)

    sorted_word = fr.quick_sort(words)
    word_freq(words,sorted_word,args)

def word_freq(data: Dict,keys: List[str],args: Tuple)->List[int]:
    """
    Calculate the frequencie of a list of word and sort them by number of occurences and plot the result
    :param data: Dictionary of words
    :param keys: List of keys of the dictionary
    :param args: arguments passed by the user
    :return: List of int (frequencies)
    """
    if args.word not in data:
        print('Error: ' + args.word+' does not appear in '+ args.file_name)
        exit()
    else:
        print(args.word +' is ranked #'+ str(data[args.word].rank))
    if args.plot:
        y = np.array([])
        x = np.array([])
        for i in range(0,len(keys)):
            k = keys[len(keys)-1-i]
            j = keys[i]
            x = np.append(x,len(keys)-(data[j].rank-1))
            y= np.append(y,data[k].total_occurence)

        searched_word_x = np.array(data[args.word].rank)
        searched_word_y = np.array(data[args.word].total_occurence)
        marker_style = dict(color='tab:blue', linestyle=':', marker='o',
                    markersize=15, markerfacecoloralt='tab:red')
        plt.scatter(x,y,marker=".",color='blue',s=85, edgecolors='black')


        plt.annotate(args.word,(searched_word_x,searched_word_y),xytext = (searched_word_x+(searched_word_x*0.04),searched_word_y+(searched_word_y*0.04)), zorder=101)

        plt.scatter(searched_word_x,searched_word_y,s=100,marker='*', color='red',alpha=1,zorder=100)
        plt.loglog(x,y,color='green')

    if args.output != None:
        global max_n
        max_n = int(args.output)
        if int(args.output) > len(keys):
            max_n = len(keys)
        for x in range(0,max_n):
            print ("#"+str(x+1)+ ": " + keys[len(keys)-1-x])

    plt.title('Word frequencies: '+args.file_name)
    plt.xlabel('Rank of word ("' + args.word + '" is ranked '+ str(data[args.word].rank)+')')
    plt.ylabel('Total number of occurences')
    plt.tick_params(bottom = True, top = True, left = True, right = True)
    plt.margins(0)
    plt.show()

if __name__ == '__main__':
    main()